# Ransomware Canary Detector

Official setup for PyPI & Docker.